public class Link3 {
// -------------------------------------------------------------
    public long dData;                // data item
    public Link3 next;                 // next link in list
// -------------------------------------------------------------
    public Link3(long d)               // constructor
        { dData = d; }
// -------------------------------------------------------------
    public void displayLink()         // display this link
        { System.out.print(dData + " "); }
// -------------------------------------------------------------
}   // end class Link
////////////////////////////////////////////////////////////////
